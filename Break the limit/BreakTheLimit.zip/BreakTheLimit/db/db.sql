-- CREATE users table
CREATE TABLE users (
  id SERIAL PRIMARY KEY,
  name VARCHAR(255) DEFAULT "Anonymous",
  username VARCHAR(255) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL
);

-- INSERT users
INSERT INTO users (name, username, password) VALUES
  ('Admin', 'admin', '$2y$10$tWWraH/PZe88umVJB3O9wuCNo/QdquyIT3lNxOEPjD54b83DcK5..');