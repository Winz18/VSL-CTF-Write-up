<?php
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
try{
    $database = new mysqli(getenv('MYSQL_HOSTNAME'), getenv('MYSQL_USER'), getenv('MYSQL_PASSWORD'), getenv('MYSQL_DATABASE'));
} catch (Exception $e) {
    die('Connection failed');
}
if ($database->connect_error) {
    die('Connection failed: ' . $database->connect_error);
}
