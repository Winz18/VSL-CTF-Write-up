<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home Page</title>
    <!-- Bootstrap CSS -->

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="icon" href="static/img/logo.ico" type="image/x-icon">
    <link rel="stylesheet" href="static/css/style.css">

</head>

<body>
    <!-- Navbar -->
    <?php include('navbar.php'); ?>

    <!-- Hero Section -->
    <header class="hero-section">
        <div class="container">
            <h1 class="hero-title">Welcome to Our Site 2</h1>
            <p class="hero-description">We specialize in providing the evil internet services you need. Explore our site to learn more about what we offer.</p>
        </div>
    </header>

    <!-- Content Section -->
    <section class="content-section height-100">
        <div class="container">
            <h2 class="text-center content-title">Our Services</h2>
            <div class="row">
                <!-- Service 1 -->
                <div class="col-md-4 mb-4">
                    <div class="card card-custom">
                        <img src="static/img/image-1.jpg" class="card-img-top" alt="Service 1">
                        <div class="card-body">
                            <h5 class="card-title">Hacker</h5>
                            <p class="card-text">We provide you a team of professional hackers who can hack anything you want.</p>
                            <a href="#" class="btn btn-primary">Read More</a>
                        </div>
                    </div>
                </div>
                <!-- Service 2 -->
                <div class="col-md-4 mb-4">
                    <div class="card card-custom">
                        <img src="static/img/image-2.png" class="card-img-top" alt="Service 2">
                        <div class="card-body">
                            <h5 class="card-title">0day Market</h5>
                            <p class="card-text">The market for unknown vulnerabilities may have the target you're aiming for.</p>
                            <a href="#" class="btn btn-primary">Read More</a>
                        </div>
                    </div>
                </div>
                <!-- Service 3 -->
                <div class="col-md-4 mb-4">
                    <div class="card card-custom">
                        <img src="static/img/image-3.png" class="card-img-top" alt="Service 3">
                        <div class="card-body">
                            <h5 class="card-title">Flag</h5>
                            <p class="card-text">The flags are full of mystery, do you want to see what it is?</p>
                            <a href="#" class="btn btn-primary">Read More</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <?php include('footer.php'); ?>
    <!-- Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>

</html>