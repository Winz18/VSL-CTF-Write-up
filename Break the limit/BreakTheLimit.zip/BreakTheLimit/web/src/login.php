<?php
include('connect.php');
session_start();

if (isset($_SESSION['user'])) {
    header('Location: profile.php');
    exit;
}

if (isset($_POST['username']) && isset($_POST['password'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $query = $database->prepare('SELECT * FROM users WHERE username = ?');
    $query->bind_param('s', $username);
    $query->execute();
    $result = $query->get_result();
    $query->close();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();

        if (password_verify($password, $user['password'])) {
            $_SESSION['user'] = $user['id'];
            $logFile = fopen('/tmp/log-' . $username . '.txt', 'wa');
            $logContent = '<b>' . date('Y-m-d H:i:s') . '</b>' . ': <b>' . $user['name'] . '</b> - ' . 'Logged in<br>';
            fwrite($logFile, $logContent);
            fclose($logFile);
            header('Location: index.php');
            exit;
        } else {
            // Password incorrect javascript alert
            echo '<div class="alert alert-danger" role="alert">Password incorrect!</div>';
        }
    } else {
        // Username not found javascript alert
        echo '<div class="alert alert-danger" role="alert">Username not found!</div>';
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="icon" href="static/img/logo.ico" type="image/x-icon">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="static/css/style.css">
</head>

<body>
    <!-- Navbar -->
    <?php include('navbar.php'); ?>

    <!-- Login Form -->
    <div class="container">
        <div class="login-container">
            <h2 class="text-center mb-4">Login</h2>
            <form method="POST">
                <div class="mb-3">
                    <label for="username" class="form-label">Username</label>
                    <input type="text" class="form-control" name="username" id="username" placeholder="Enter your username">
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label">Password</label>
                    <input type="password" class="form-control" name="password" id="password" placeholder="Enter your password">
                </div>
                <button type="submit" class="btn btn-primary w-100">Login</button>
                <div class="mt-3 text-center">
                    <a href="register.php" class="register-btn">Register</a>

                </div>
            </form>
        </div>
    </div>

    <?php include('footer.php'); ?>

    <!-- Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>

</html>