<nav class="navbar navbar-expand-lg navbar-custom fixed-top">
    <div class="container">
        <a class="navbar-brand" href="index.php">VSL's Site</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link" href="index.php">Home</a>
                </li>
                <?php
                if (isset($_SESSION['user'])) {
                    echo '<li class="nav-item">';
                    echo '<a class="nav-link" href="profile.php">Profile</a>';
                    echo '</li>';
                    echo '<li class="nav-item">';
                    echo '<a class="nav-link" href="logout.php">Logout</a>';
                    echo '</li>';
                }else {
                    echo '<li class="nav-item">';
                    echo '<a class="nav-link" href="login.php">Login</a>';
                    echo '</li>';
                }
                ?>
            </ul>
        </div>
    </div>
</nav>