<?php
include('connect.php');
session_start();


// Kiểm tra nếu người dùng chưa đăng nhập, chuyển hướng về trang đăng nhập
if (!isset($_SESSION['user'])) {
    header('Location: login.php');
    exit;
}

// Lấy thông tin người dùng từ cơ sở dữ liệu
$query = $database->prepare('SELECT * FROM users WHERE id = ?');
$query->bind_param('i', $_SESSION['user']);
$query->execute();
$result = $query->get_result();
$query->close();

if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
} else {
    header('Location: logout.php');
    exit;
}

if (isset($_POST['form-password'])) {
    $currentPassword = $_POST['current-password'];
    $newPassword = $_POST['new-password'];
    $confirmNewPassword = $_POST['confirm-new-password'];

    $query = $database->prepare('SELECT * FROM users WHERE id = ?');
    $query->bind_param('i', $_SESSION['user']);
    $query->execute();
    $result = $query->get_result();
    $query->close();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();

        if (password_verify($currentPassword, $user['password'])) {
            if ($newPassword != $confirmNewPassword) {
                echo '<div class="alert alert-danger" role="alert">New passwords do not match!</div>';
            } else {
                $query = $database->prepare('UPDATE users SET password = ? WHERE id = ?');
                $query->bind_param('si', password_hash($newPassword, PASSWORD_DEFAULT), $_SESSION['user']);
                $query->execute();
                $query->close();

                // Generate log file of own user
                $logFile = fopen('/tmp/log-' . $user['username'] . '.txt', 'a');
                $logContent = '<b>' . date('Y-m-d H:i:s') . '</b>' . ':  You have changed password<br>';
                fwrite($logFile, $logContent);
                fclose($logFile);
                echo '<div class="alert alert-success" role="alert">Password changed successfully!</div>';
            }
        } else {
            echo '<div class="alert alert-danger" role="alert">Current password incorrect!</div>';
        }
    } else {
        // Trường hợp không tìm thấy thông tin người dùng (điều này không nên xảy ra)
        header('Location: logout.php');
        exit;
    }
}

if (isset($_POST['form-info'])) {
    $name = $_POST['name'];
    if (empty($name) || trim($name) == '') {
        echo '<div class="alert alert-danger" role="alert">Name cannot be empty!</div>';
        return;
    }
    if (strlen($name) > 10) {
        echo '<div class="alert alert-danger" role="alert">Name cannot be longer than 12 characters!</div>';
        return;
    }
    $query = $database->prepare('UPDATE users SET name = ? WHERE id = ?');
    $query->bind_param('si', $name, $_SESSION['user']);
    $query->execute();
    $query->close();

    // Generate log file of own user
    $query = $database->prepare('SELECT * FROM users WHERE id = ?');
    $query->bind_param('i', $_SESSION['user']);
    $query->execute();
    $result = $query->get_result();
    $query->close();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();

        $logFile = fopen('/tmp/log-' . $user['username'] . '.txt', 'a');
        $logContent = '<b>' . date('Y-m-d H:i:s') . '</b>' . ': You have changed your name to ' . '<b class="color: red;">' .$name . '</b><br>';
        fwrite($logFile, $logContent);
        fclose($logFile);
    }

    echo '<div class="alert alert-success" role="alert">Information changed successfully!</div>';
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile Page</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="icon" href="static/img/logo.ico" type="image/x-icon">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="static/css/style.css">
</head>

<body>
    <?php include('navbar.php'); ?>

    <div class="profile-container">
        <div class="avatar-section">
            <h4>Profile Settings</h4>
            <img src="static/img/avatar.png" alt="User Avatar" class="avatar">
            <h3><?php echo htmlspecialchars($user['username'], ENT_QUOTES, 'UTF-8'); ?></h3>
            <p>Your alias: <?php echo htmlspecialchars($user['name'], ENT_QUOTES, 'UTF-8'); ?></p>
            <div class="list-group mb-3">
                <a href="#changePassword" class="list-group-item list-group-item-action">Change Password</a>
                <a href="#changeInfo" class="list-group-item list-group-item-action">Change Information</a>
                <a href="#viewLog" class="list-group-item list-group-item-action">View Log</a>
            </div>
            <a href="logout.php" class="btn btn-logout w-100">Logout</a>

        </div>

        <div class="nav-section">
            <div id="changePassword" class="mt-4 hidden">
                <h5>Change Password</h5>
                <!-- Change password form or content here -->
                <form method="POST">
                    <input type="hidden" name="form-password">
                    <div class="mb-3">
                        <label for="current-password" class="form-label profile-label">Current Password</label>
                        <input type="password" class="form-control" name="current-password" id="current-password" placeholder="Enter your current password">
                    </div>
                    <div class="mb-3">
                        <label for="new-password" class="form-label profile-label">New Password</label>
                        <input type="password" class="form-control" name="new-password" id="new-password" placeholder="Enter your new password">
                    </div>
                    <div class="mb-3">
                        <label for="confirm-new-password" class="form-label profile-label">Confirm New Password</label>
                        <input type="password" class="form-control" name="confirm-new-password" id="confirm-new-password" placeholder="Confirm your new password">
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Change Password</button>
                </form>
            </div>

            <div id="changeInfo" class="mt-4 hidden">
                <h5>Change Information</h5>
                <!-- Change information form or content here -->
                <form method="POST">
                    <input type="hidden" name="form-info">
                    <div class="mb-3">
                        <label for="name" class="form-label profile-label">Your alias</label>
                        <input type="name" class="form-control" name="name" id="name" placeholder="Enter your alias" value="<?php echo htmlspecialchars($user['name'], ENT_QUOTES, 'UTF-8'); ?>">
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Change Information</button>
                </form>
            </div>

            <div id="viewLog" class="mt-4 hidden">
                <h5>View Log</h5>
                <!-- Log viewing content here -->
                <div class="log-content">
                    <p>Log content goes here...</p>
                    <p>
                        <?php
                            try {
                                include('/tmp/log-' . $user['username'] . '.txt');
                            }catch (Exception $e) {
                                echo 'Log file not found or cannot be read, please logout and login again to generate a new log file.';
                            }
                        ?>
                    </p>
                </div>
            </div>
        </div>
    </div>

    <?php include('footer.php'); ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script src="static/js/script.js"></script>
</body>

</html>