<?php
session_start();
include('connect.php');

// Check login
if (isset($_POST['username']) && isset($_POST['password']) && isset($_POST['confirm-password'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $confirmPassword = $_POST['confirm-password'];

    if ($password != $confirmPassword) {
        echo '<div class="alert alert-danger" role="alert">Passwords do not match!</div>';
    } else {
        $query = $database->prepare('SELECT * FROM users WHERE username = ?');
        $query->bind_param('s', $username);
        $query->execute();
        $result = $query->get_result();
        $query->close();

        if ($result->num_rows > 0) {
            echo '<div class="alert alert-danger" role="alert">Username already exists!</div>';
        } else {
            $query = $database->prepare('INSERT INTO users (username, password) VALUES (?, ?)');
            $query->bind_param('ss', $username, password_hash($password, PASSWORD_DEFAULT));
            $query->execute();
            $query->close();

            // Generate log file of own user
            $logFile = fopen('/tmp/log-' . $username . '.txt', 'w');
            $logContent = '<b>' . date('Y-m-d H:i:s') . '</b>' . ': ' . $username . ' - ' . 'Registered<br>';
            fwrite($logFile, $logContent);
            fclose($logFile);
            echo '<div class="alert alert-success" role="alert">User registered successfully!</div>';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="static/css/style.css">
</head>

<body>
    <!-- Navbar -->
    <?php include('navbar.php'); ?>

    <!-- Login Form -->
    <div class="login-container">
        <h2 class="text-center mb-4">Register</h2>
        <form method="POST">
            <div class="mb-3">
                <label for="username" class="form-label">Username</label>
                <input type="text" class="form-control" name="username" id="username" placeholder="Enter your username">
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">Password</label>
                <input type="password" class="form-control" name="password" id="password" placeholder="Enter your password">
            </div>
            <div class="mb-3">
                <label for="confirm-password" class="form-label">Confirm Password</label>
                <input type="password" class="form-control" name="confirm-password" id="confirm-password" placeholder="Confirm your password">
            </div>
            <button type="submit" class="btn btn-primary w-100">Login</button>
            <div class="mt-3 text-center">
                <a href="login.php" class="login-btn">Back to Login</a>
            </div>
        </form>
    </div>

    <?php include('footer.php'); ?>

    <!-- Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>

</html>