document.addEventListener('DOMContentLoaded', function () {
    const listGroupItems = document.querySelectorAll('.list-group-item');
    const sections = document.querySelectorAll('.nav-section > div');

    listGroupItems.forEach((item, index) => {
        item.addEventListener('click', () => {
            sections.forEach(section => {
                section.classList.add('hidden');
            });

            sections[index].classList.remove('hidden');
        });
    });
});